package gamemain;

public enum ID {

	Player(),
	//Player2(),
	BasicEnemy(),
	Trail(),
	FastEnemy(),
	SmartEnemy(),
	MenuParticle(),
	EnemyBoss();
}
